### Dataset

- V súbore dataset.csv sú uložené nami už predspracované dáta do testovania hypotéz

- V súbote SpeedDatingData.csv sú uložené pôvodné surové dáta z kaggle

### Poznamka z minulosti :P 


michalkc  7:22 PM
Tento dataset vidim poprve a vizera zaujimavo. Ak mi mobil neklame, malo by to mat podobu nested lustu/data frame a teda to bude chciet nejaku rekurziu pri spracovani.
7:23
Hypoteza inak za 5 bonusovych bodov :)


